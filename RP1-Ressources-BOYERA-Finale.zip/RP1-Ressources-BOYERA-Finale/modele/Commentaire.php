<?php
require_once(__DIR__ . '/../include/outils_bd.php');

class Commentaire {
    public int $id;
    public int $idUtilisateur;
    public int $idPost;
    public string $contenu;
    public string $dateCommentaire;
    public string $prenom;
    public string $nom;
    public ?string $photo_profil;

    public function __construct(array $uneLigne) {
        $this->id = $uneLigne['id'];
        $this->contenu = $uneLigne['contenu'];
        $this->idUtilisateur = $uneLigne['idUtilisateur'];
        $this->idPost = $uneLigne['idPost'];
        $this->dateCommentaire = $uneLigne['date'];
        $this->prenom = $uneLigne['prenom'];
        $this->nom = $uneLigne['nom'];
        $this->photo_profil = $uneLigne['photo_profil'];
    }
    
    // Créer un nouveau commentaire
    public static function creer(string $contenu, int $idUtilisateur, int $idPost): bool {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO commentaires (contenu, idUtilisateur, idPost) VALUES (?, ?, ?)");
        return $stmt->execute([$contenu, $idUtilisateur, $idPost]);
    }

    // Supprimer un commentaire
    public static function supprimer(int $idCommentaire, int $idUtilisateur): bool {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM commentaires WHERE id = ? AND idUtilisateur = ?");
        return $stmt->execute([$idCommentaire, $idUtilisateur]);
    }

    public static function getCommentairesParPost(int $idPost): array {
        global $pdo;
        $stmt = $pdo->prepare("
            SELECT commentaires.*, u.prenom, u.nom, u.photo_profil
            FROM commentaires
            JOIN utilisateurs u ON commentaires.idUtilisateur = u.id
            WHERE commentaires.idPost = ?
            ORDER BY commentaires.id");
        $stmt->execute([$idPost]);
        $commentaires = [];

        while ($uneLigne = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $commentaires[] = new Commentaire($uneLigne);
        }

        return $commentaires;
    }


    // $sql = "SELECT c.*, u.prenom, u.nom, u.photo_profil
    //         FROM commentaires c
    //         INNER JOIN utilisateurs u ON c.utilisateur_id = u.id
    //         WHERE c.post_id = ?
    //         ORDER BY c.dateCommentaire ASC";
}
