<?php
class Utilisateur {
    public static function getParId(PDO $pdo, int $id): ?array {
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function mettreAJour(PDO $pdo, int $id, string $nom, string $prenom, string $email): bool {
        $stmt = $pdo->prepare("UPDATE utilisateurs SET nom = ?, prenom = ?, email = ? WHERE id = ?");
        return $stmt->execute([$nom, $prenom, $email, $id]);
    }

    public static function changerMotDePasse(PDO $pdo, int $id, string $motDePasseHash): bool {
        $stmt = $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
        return $stmt->execute([$motDePasseHash, $id]);
    }

    public static function verifierAncienMotDePasse(PDO $pdo, int $id, string $ancienMdp): bool {
        $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        return $user && password_verify($ancienMdp, $user['mot_de_passe']);
    }
}
