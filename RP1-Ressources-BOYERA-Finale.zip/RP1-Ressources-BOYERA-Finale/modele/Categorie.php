<?php
require_once 'include/outils_bd.php';
class Categorie {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAll() {
        return $this->db->query("SELECT * FROM categories")->fetchAll();
    }

    public function getPostsByCategorie($categorie_id) {
        $stmt = $this->db->prepare("SELECT posts.*, utilisateurs.nom, utilisateurs.prenom FROM posts
        INNER JOIN utilisateurs ON posts.utilisateur_id = utilisateurs.id 
        WHERE posts.idCategorie = ? AND posts.statut = 'validé'");
        $stmt->execute([$categorie_id]);
        return $stmt->fetchAll();
    }
}
?>
