<?php
require_once 'include/outils_bd.php';

class Post {

    // Fonction pour récupérer tous les posts
    public function getPosts() {
        global $pdo;

        $stmt = $pdo->query("SELECT * FROM posts WHERE statut = 'validé' ORDER BY date_post DESC");
        return $stmt->fetchAll();
    }

    // Fonction pour récupérer un post par son ID
    public function getPostById($id) {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Fonction pour créer un post
    public function createPost($titre, $contenu, $utilisateur_id) {
        global $pdo;

        $stmt = $pdo->prepare("INSERT INTO posts (titre, contenu, utilisateur_id) VALUES (:titre, :contenu, :utilisateur_id)");
        $stmt->bindParam(':titre', $titre);
        $stmt->bindParam(':contenu', $contenu);
        $stmt->bindParam(':utilisateur_id', $utilisateur_id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Fonction pour mettre à jour un post (validation, suppression, etc.)
    public function updatePostStatus($post_id, $statut) {
        global $pdo;

        $stmt = $pdo->prepare("UPDATE posts SET statut = :statut WHERE id = :post_id");
        $stmt->bindParam(':statut', $statut);
        $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
        return $stmt->execute();
    }
    
}

?>
