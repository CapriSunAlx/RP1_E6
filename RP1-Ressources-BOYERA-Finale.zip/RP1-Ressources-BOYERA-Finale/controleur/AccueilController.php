<?php
class AccueilController {
    public function index() {

        include 'vue/home-vue.php';
    }
}
?>
