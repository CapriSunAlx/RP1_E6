<?php
session_start();
require_once(__DIR__ . '/../modele/Commentaire.php');

if (!isset($_SESSION['id'])) {
    header('Location: ../commun.php');
    exit();
}

$idUtilisateur = $_SESSION['id'];

// ajouter un commentaire 
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['contenu'], $_POST['idPost'])) {
    $contenu = trim($_POST['contenu']);
    $idPost = (int) $_POST['idPost'];

    if ($contenu !== '') {
        try {
            Commentaire::creer($contenu, $idUtilisateur, $idPost);
        } catch (PDOException $e) {
            $sqlstate = $e->errorInfo[0];
            if ($sqlstate == '45001') {
                $_SESSION['error_comment'] = "Trop de commentaires postés rapidement. Attendez 5 minutes.";
            } else {
                $_SESSION['error_comment'] = "Erreur lors de l'ajout du commentaire : " . $e->getMessage();
            }

            header("Location: ../index.php?page=post&id=" . $idPost);
            exit();
        }
    }

    header("Location: ../index.php?page=post&id=" . $idPost);
    exit();
}

// supprimer un commentaire
if (isset($_GET['supprimer'], $_GET['id'], $_GET['post'])) {
    $idCommentaire = (int) $_GET['id'];
    $idPost = (int) $_GET['post'];

    Commentaire::supprimer($idCommentaire, $idUtilisateur);

    header("Location: ../index.php?page=post&id=" . $idPost);
    exit();
}
