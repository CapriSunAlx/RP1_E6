<?php
require_once 'modele/Categorie.php';

class CategorieController {
    private $categorieModel;

    public function __construct($db) {
        $this->categorieModel = new Categorie($db); 
    }

    public function afficherPostsCategorie($categorie_id) {
        $posts = $this->categorieModel->getPostsByCategorie($categorie_id);

        require_once 'vue/categorie-vue.php'; 
    }
}
?>
