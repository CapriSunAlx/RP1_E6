<?php
session_start();

require_once "../include/outils_bd.php";

// le formulaire a ete soumis avec les bon champs
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['titre'], $_POST['contenu']) && isset($_SESSION['id'])) {
    
    // Récupérer les données du formulaire
    $titre = ($_POST['titre']);
    $contenu = ($_POST['contenu']);
    $utilisateur_id = $_SESSION['id'];
    $idCategorie = (int) ($_POST['idCategorie']);
    $statut = "validé"; 

    // Requete preparee pour insérer le post
    $requete = "INSERT INTO posts (titre, contenu, utilisateur_id, date_post, statut, idCategorie) 
                VALUES (?, ?, ?, NOW(), ?, ?)";
    
    try {
    $sth = $pdo->prepare($requete);
    $sth->execute([$titre, $contenu, $utilisateur_id, $statut, $idCategorie]);

    unset($_SESSION['error_post']);
    header('Location: ../categorie.php?categorie_id=' . $idCategorie);
    exit();

} catch (PDOException $e) {
    $sqlstate = $e->errorInfo[0];

    if ($sqlstate == '45000') {
        $_SESSION['error_post'] = "Vous avez atteint la limite de 3 posts aujourd'hui. Réessayez demain.";
    } else {
        $_SESSION['error_post'] = "Erreur lors de l'ajout du post : " . $e->getMessage();
    }

    header('Location: ../categorie.php?categorie_id=' . $idCategorie);
    exit();
}

}
?>
