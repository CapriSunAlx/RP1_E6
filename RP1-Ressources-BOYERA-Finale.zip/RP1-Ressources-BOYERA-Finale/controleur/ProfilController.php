<?php
require_once 'modele/Utilisateur.php';

class ProfilController {
    public function afficherProfil() {
        if (!isset($_SESSION['id'])) {
            header('Location: index.php?page=connexion');
            exit;
        }

        global $pdo;
        $utilisateur = Utilisateur::getParId($pdo, $_SESSION['id']);
        require 'vue/profil-vue.php';
    }

    public function modifierProfil() {
        global $pdo;
        $message = "";

        if (!isset($_SESSION['id'])) {
            header('Location: index.php?page=connexion');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email'])) {
                // Validation de l'email
                if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                    $message = "Format d'email invalide.";
                } else {
                    $success = Utilisateur::mettreAJour($pdo, $_SESSION['id'], $_POST['nom'], $_POST['prenom'], $_POST['email']);
                    if ($success) {
                        $_SESSION['nom'] = $_POST['nom'];
                        $_SESSION['prenom'] = $_POST['prenom'];
                        $_SESSION['email'] = $_POST['email'];
                        $message = "Profil mis à jour avec succès.";
                    } else {
                        $message = "Erreur lors de la mise à jour.";
                    }
                }
            } else {
                $message = "Tous les champs sont requis.";
            }
        }

        $utilisateur = Utilisateur::getParId($pdo, $_SESSION['id']);
        require 'vue/profil-vue.php';
    }

    public function modifierMotDePasse() {
        // Vérifier si l'utilisateur est connecté
        if (!isset($_SESSION['id'])) {
            header('Location: index.php?page=connexion');
            exit;
        }
    
        // Récupérer les données du formulaire
        $ancien_mdp = $_POST['ancien_mdp'];
        $nouveau_mdp = $_POST['nouveau_mdp'];
        $confirm_mdp = $_POST['confirm_mdp'];
    
        global $pdo;
    
        // Récupérer le mot de passe actuel en base
        $sql = "SELECT mot_de_passe FROM utilisateurs WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_SESSION['id']]);
        $utilisateur = $stmt->fetch();
    
        // Vérifier l'ancien mot de passe
        if (!password_verify($ancien_mdp, $utilisateur['mot_de_passe'])) {
            $_SESSION['erreurMdp'] = "L'ancien mot de passe est incorrect.";
        } 
        // Vérifier que les nouveaux mots de passe correspondent
        elseif ($nouveau_mdp != $confirm_mdp) {
            $_SESSION['erreurMdp'] = "Les mots de passe ne correspondent pas.";
        } else {
            $nouveau_hash = password_hash($nouveau_mdp, PASSWORD_DEFAULT);
            
            $sql = "UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $resultat = $stmt->execute([$nouveau_hash, $_SESSION['id']]);
            
            if ($resultat) {
                $_SESSION['messageMdp'] = "Mot de passe modifié avec succès !";
            } else {
                $_SESSION['erreurMdp'] = "Erreur lors de la modification.";
            }
        }
    
        // Retour à la page profil
        header('Location: index.php?page=profil');
        exit;
    }

    // Modifier la photo de profil
    public function modifierPhoto() {
        global $pdo;

        if (!isset($_SESSION['id'])) {
            header('Location: index.php?page=connexion');
            exit;
        }

        $messagepdp = '';

        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
            // Vérifications de sécurité
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $maxSize = 5 * 1024 * 1024; // 5MB
            
            if (!in_array($_FILES['photo']['type'], $allowedTypes)) {
                $messagepdp = "Type de fichier non autorisé. Seuls JPG, PNG, GIF et WebP sont acceptés.";
            } elseif ($_FILES['photo']['size'] > $maxSize) {
                $messagepdp = "Le fichier est trop volumineux. Taille maximale : 5MB.";
            } else {
                $tmp = $_FILES['photo']['tmp_name'];
                $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                $nomFichier = uniqid() . '.' . $ext;
                $chemin = 'images/' . $nomFichier;

                // Créer le dossier s'il n'existe pas
                if (!is_dir('images')) {
                    mkdir('images', 0755, true);
                }

                if (move_uploaded_file($tmp, $chemin)) {
                    try {
                        // Récupérer l'ancienne photo pour la supprimer
                        $stmt = $pdo->prepare("SELECT photo_profil FROM utilisateurs WHERE id = ?");
                        $stmt->execute([$_SESSION['id']]);
                        $oldPhoto = $stmt->fetchColumn();

                        // Mettre à jour la photo
                        $stmt = $pdo->prepare("UPDATE utilisateurs SET photo_profil = ? WHERE id = ?");
                        $success = $stmt->execute([$chemin, $_SESSION['id']]);

                        if ($success) {
                            // Supprimer l'ancienne photo si elle existe et n'est pas la photo par défaut
                            if ($oldPhoto && $oldPhoto !== 'images/profil.png' && file_exists($oldPhoto)) {
                                unlink($oldPhoto);
                            }
                            $_SESSION['messagepdp'] = "Photo mise à jour avec succès.";
                        } else {
                            $messagepdp = "Erreur lors de la mise à jour en base de données.";
                        }
                    } catch (PDOException $e) {
                        $messagepdp = "Erreur de base de données.";
                        error_log("Erreur PDO dans modifierPhoto: " . $e->getMessage());
                    }
                } else {
                    $messagepdp = "Erreur lors de l'upload du fichier.";
                }
            }
        } else {
            $messagepdp = "Aucune image reçue ou erreur d'upload.";
        }

        // Redirection avec message
        if (!empty($messagepdp)) {
            $_SESSION['messagepdp'] = $messagepdp;
        }
        
        header('Location: index.php?page=profil');
        exit;
    }
}