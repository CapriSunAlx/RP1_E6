<?php

require_once 'include/outils_bd.php';

class InscriptionController {
    
    public function afficherFormulaire() {
        $titre = "Inscription - Forum";
        require_once 'vue/inscription-vue.php';
    }

    public function traiterInscription($post) {
        if (empty($post['prenom']) || empty($post['nom']) || empty($post['email']) || empty($post['mot_de_passe'])) {
            return "Tous les champs doivent être remplis.";
        }
        
        if (!filter_var($post['email'], FILTER_VALIDATE_EMAIL)) {
            return "L'email n'est pas valide.";
        }

        $motDePasseHash = password_hash($post['mot_de_passe'], PASSWORD_DEFAULT);

        global $pdo;

        $stmt = $pdo->prepare("INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe) VALUES (?, ?, ?, ?)");

        // Exécution de la requête
        if ($stmt->execute([$post['prenom'], $post['nom'], $post['email'], $motDePasseHash])) {
            header("Location: index.php?page=connexion");
            exit();
        } else {
            return "Une erreur est survenue lors de l'inscription.";
        }
    }
}
