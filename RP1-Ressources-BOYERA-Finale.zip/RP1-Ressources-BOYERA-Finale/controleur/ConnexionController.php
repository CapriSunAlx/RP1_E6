<?php

class ConnexionController {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function afficherFormulaire() {
        require_once 'vue/connexion-vue.php';
    }

    public function connexionUtilisateur($donnees) {
        require_once 'include/outils_bd.php';

        // Vérif des inputs
        if (empty($donnees['email']) || empty($donnees['mot_de_passe'])) {
            $message = "Veuillez remplir tous les champs.";
            require_once 'vue/connexion-vue.php';
            return;
        }

        $email = $donnees['email'];
        $mot_de_passe = $donnees['mot_de_passe'];

        // Vérif des identifiants
        $stmt = $this->pdo->prepare("SELECT * FROM utilisateurs WHERE email = :email");
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        $utilisateur = $stmt->fetch();

        if ($utilisateur && password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
            $_SESSION['id'] = $utilisateur['id'];
            $_SESSION['email'] = $utilisateur['email'];
            $_SESSION['role'] = $utilisateur['role'];
            $_SESSION['nom'] = $utilisateur['nom'];
            $_SESSION['prenom'] = $utilisateur['prenom'];

            header('Location: index.php');
            exit;
        } else {
            $message = "Identifiants incorrects, veuillez réessayer.";
            require_once 'vue/connexion-vue.php';
        }
    }

    public function reinitMotDePasse($donnees) {
        require_once 'include/outils_bd.php';
        require_once 'include/mail.php';

        if (!isset($donnees['email']) || empty($donnees['email'])) {
            echo "Adresse e-mail manquante.";
            return;
        }

        $email = $donnees['email'];

        // Vérification de l'existence de l'utilisateur
        $stmt = $this->pdo->prepare("SELECT id, prenom FROM utilisateurs WHERE email = ?");
        $stmt->execute([$email]);
        $utilisateur = $stmt->fetch();

        if (!$utilisateur) {
            echo "Aucun utilisateur trouvé.";
            return;
        }

        $id = $utilisateur['id'];
        $prenom = $utilisateur['prenom'];

        // Génération d'un token avec expiration (30 minutes)
        $expiration = time() + (30 * 60);
        $token = base64_encode("$id|$expiration");
        $lien = "http://172.18.153.44/index.php?page=connexion&action=reset&token=$token";

        // Préparation et envoi du mail
$message = "
Bonjour $prenom,

Un nouveau mot de passe a été demandé pour votre compte NextGen Forum ($email).
Si vous n'êtes pas à l'origine de cette demande, veuillez ignorer ce message.

Veuillez cliquer sur le lien suivant pour réinitialiser votre mot de passe : $lien

Ce lien expirera dans 30 minutes.";

envoyerMail($email, "Reinitialisation du mot de passe", $message);

// message de confirmation
echo '<div class="container mt-5">
<div class="alert alert-success text-center">Un e-mail de réinitialisation vous a été envoyé.</div>
    </div>';
    }

    public function resetMotDePasseDepuisLien($token) {
        require_once 'include/outils_bd.php';

        $decode = base64_decode($token);
        [$id, $expiration] = explode('|', $decode);

        // Vérification de l'expiration du lien
        if (time() > $expiration) {
            echo "Lien expiré. Veuillez refaire une demande.";
            return;
        }

        // Génération d'un nouveau mot de passe
        $nouveauMdp = bin2hex(random_bytes(5)); // 10 caractères
        $mdpHash = password_hash($nouveauMdp, PASSWORD_DEFAULT);

        // Mise à jour du mot de passe
        $stmt = $this->pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
        $stmt->execute([$mdpHash, $id]);

        // message de confirmation
     echo '<div class="container mt-5">
    <div class="alert alert-success text-center">Votre mot de passe a été réinitialisé, nous vous prions de le modifier au plus vite. Nouveau mot de passe : <strong>' . $nouveauMdp . '</strong></div>
            </div>';
    }
}
?>