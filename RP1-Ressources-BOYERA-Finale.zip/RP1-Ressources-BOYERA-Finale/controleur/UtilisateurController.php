<?php

require_once 'modele/Utilisateur.php';

class UtilisateurController {
    public function modifierInfos() {
        global $pdo;
        $message = "";

        // Récupérer l'identifiant de l'utilisateur connecté
        $idUtilisateur = $_SESSION['id'];

        // Si le formulaire a été soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Vérifier que tous les champs sont remplis
            if (!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email'])) {
                // Mise à jour dans la base de données
                $ok = Utilisateur::mettreAJour($pdo, $idUtilisateur, $_POST['nom'], $_POST['prenom'], $_POST['email']);
                $message = $ok ? "Profil mis à jour." : "Erreur lors de la mise à jour.";
            } else {
                $message = "Tous les champs sont obligatoires.";
            }
        }

        $utilisateur = Utilisateur::getParId($pdo, $idUtilisateur);

        require 'vue/profil-vue.php';
    }

    // Modifier la photo de profil
    public function modifierPhoto() {
        global $pdo;
        $message = "";

        // Vérifier que l'utilisateur est connecté
        $idUtilisateur = $_SESSION['id'] ?? null;

        // Vérifier que le formulaire a été soumis et qu'un fichier a été envoyé
        if ($idUtilisateur && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['photo'])) {
            $photo = $_FILES['photo'];

            // Dossier où enregistrer la photo
            $dossier = 'images/';
            $nomFichier = basename($photo['name']);
            $chemin = $dossier . $nomFichier;

            // Déplacer la photo depuis le dossier temporaire vers notre dossier images
            if (move_uploaded_file($photo['tmp_name'], $chemin)) {
                // Mettre à jour le chemin de la photo dans la base
                $stmt = $pdo->prepare("UPDATE utilisateurs SET photo_profil = ? WHERE id = ?");
                $ok = $stmt->execute([$chemin, $idUtilisateur]);

                $messagepdp = $ok ? "Photo mise à jour avec succès." : "Erreur lors de la mise à jour.";
            } else {
                $messagepdp = "Erreur lors du téléchargement du fichier.";
            }
        }

        // Récupérer les infos utilisateur pour afficher la nouvelle photo
        $utilisateur = Utilisateur::getParId($pdo, $idUtilisateur);

        // Afficher la vue du profil
        require 'vue/profil-vue.php';
    }



    // public function modifierMotDePasse() {
    //     global $pdo;
    //     session_start();

    //     $message = "";

    //     $idUtilisateur = $_SESSION['idUtilisateur'];

    //     if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //         if (!empty($_POST['ancien_mdp']) && !empty($_POST['nouveau_mdp']) && $_POST['nouveau_mdp'] === $_POST['confirmer_mdp']) {
    //             $verif = Utilisateur::verifierAncienMotDePasse($pdo, $idUtilisateur, $_POST['ancien_mdp']);
    //             if ($verif) {
    //                 $hash = password_hash($_POST['nouveau_mdp'], PASSWORD_DEFAULT);
    //                 $ok = Utilisateur::changerMotDePasse($pdo, $idUtilisateur, $hash);
    //                 $message = $ok ? "Mot de passe modifié." : "Erreur lors du changement du mot de passe.";
    //             } else {
    //                 $message = "Ancien mot de passe incorrect.";
    //             }
    //         } else {
    //             $message = "Vérifiez les champs du formulaire.";
    //         }
    //     }

    //     $utilisateur = Utilisateur::getParId($pdo, $idUtilisateur);
    //     require 'vue/profil-vue.php';
    // }
}
