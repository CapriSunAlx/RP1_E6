<?php
require_once 'include/outils_bd.php';
require_once 'controleur/CategorieController.php';

$categorie_id = isset($_GET['categorie_id']) ? $_GET['categorie_id'] : 1;

$categorieController = new CategorieController($pdo);

$categorieController->afficherPostsCategorie($categorie_id);
?>
