<?php
require_once 'include/outils_bd.php';
session_start();

require_once 'include/bandeau.php';
require_once 'controleur/CategorieController.php';

// ID de la catégorie (par défaut : 1)
$categorie_id = isset($_GET['categorie_id']) ? $_GET['categorie_id'] : 1;

// Création du contrôleur
$categorieController = new CategorieController($pdo);

// ROUTEUR
$page = isset($_GET['page']) ? $_GET['page'] : 'accueil';

// Actions pour le profil
if ($page === 'profil') {
    require_once 'controleur/ProfilController.php';
    $profilController = new ProfilController();
    
    $action = $_GET['action'] ?? 'afficher';

    switch ($action) {
        case 'afficher':
            $profilController->afficherProfil();
            break;
        case 'modifierInfos':
            $profilController->modifierProfil();
            break;
        case 'modifierPhoto':
            $profilController->modifierPhoto();
            break;
        case 'changerMotDePasse':
            $profilController->modifierMotDePasse();
            break;
        default:
            $profilController->afficherProfil();
            break;
    }
} else {

    switch ($page) {
        case 'accueil':
            include 'vue/accueil-vue.php';
            break;

       case 'connexion':
            require_once 'controleur/ConnexionController.php';
            $controleur = new ConnexionController($pdo);

            $action = $_GET['action'] ?? null;

            if ($action === 'reinit') {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $controleur->afficherFormulaire();
                    $controleur->reinitMotDePasse($_POST);
                } else {
                    $controleur->afficherFormulaire();
                }
            } elseif ($action === 'reset') {
                $controleur->resetMotDePasseDepuisLien($_GET['token']);
                $controleur->afficherFormulaire();
            } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $controleur->connexionUtilisateur($_POST);
            } else {
                $controleur->afficherFormulaire();
            }

            break;

        
        case 'mdp-oublie':
            include 'vue/mdp-oublie-vue.php';
            break;

        case 'post':
            include 'vue/post-vue.php';
            break;

        case 'commun':
            include 'commun.php';
            break;

        default:
            echo "<p>Page inconnue.</p>";
            break;
    }
}