<?php
require_once __DIR__ . '/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/phpmailer/src/SMTP.php';
require_once __DIR__ . '/phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function envoyerMail($to, $sujet, $message) {
    $mail = new PHPMailer(true);

    try {
        // Configuration SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'alexandrebyr9@gmail.com';
        $mail->Password = 'uthd eell ptly pcxt';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Expéditeur & destinataire
        $mail->setFrom('NextGen.SIO@gmail.com', 'NextGen Forum');
        $mail->addAddress($to);
        $mail->Subject = $sujet;
        $mail->Body    = $message;

        // Envoi
        $mail->send();
        return true;
    } catch (Exception $e) {
        echo "Erreur lors de l'envoi : {$mail->ErrorInfo}";
        return false;
    }
}
