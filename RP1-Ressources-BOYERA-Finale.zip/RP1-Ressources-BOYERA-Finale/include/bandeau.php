<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum d'Accueil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/style.css">
</head>

    
<?php
// Démarrer la session si ce n'est pas déjà fait
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$isConnected = isset($_SESSION['id']);
?>

<body>
<!-- Bandeau avec informations de l'user -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">Forum</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <?php if ($isConnected): ?>

                <!-- Si utilisateur connecté afficher son nom et possibilité de se déconnecter -->
                    <span class="navbar-text text-light">
                        Bonjour, 
                        <?php echo ($_SESSION['prenom']) . ' ' . ($_SESSION['nom']);?>
                    </span>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="index.php?page=profil">Mon profil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="deconnexion.php">Déconnexion</a>
                </li>
            <?php else: ?>
                <!-- Si l'utilisateur est pas connecté afficher possibilité de se connecter ou s'inscrire -->
                <li class="nav-item">
                    <a class="nav-link text-light" href="index.php?page=connexion">Se connecter</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link text-light" href="inscription.php">S'inscrire</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<!-- Footer -->
 <section>
<footer class="footer mt-auto py-3" style="position: fixed; bottom: 0; width: 100%; z-index: 999;">
    <div class="container">
        <div class="row">
            <div class="d-flex justify-content-between align-items-center">
                <p class="text-muted" style="white-space: nowrap;">&copy; 2025 Forum BTS SIO. Tous droits réservés.</p>
           

            <div class="col-md-6 text-center text-md-end">
                <ul class="list-inline mb-0">
                    <!-- <li class="list-inline-item"><a href="#" class="text-muted">Mentions Légales</a></li>
                    <li class="list-inline-item"><a href="#" class="text-muted">En savoir plus sur le projet</a></li>
                    <li class="list-inline-item"><a href="#" class="text-muted">Nous contacter</a></li> -->
                     <li class="list-inline-item"><a href="#" onclick="window.scrollTo({ top: 0, behavior: 'smooth' });">Haut de page</a></li>
                </ul>
             </div>
            </div>
        </div>
    </div>
    </section>
</footer>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>