
-- ========================================
--  Limiter les posts à 3 par jour
-- ========================================

DELIMITER //

CREATE TRIGGER limite_posts
    BEFORE INSERT ON posts
    FOR EACH ROW
BEGIN
    DECLARE nb_posts_max INT;

    SELECT COUNT(*) INTO nb_posts_max
    FROM posts 
    WHERE utilisateur_id = NEW.utilisateur_id 
    AND DATE(date_post) = CURDATE();
    
    -- bloquer si l'utilisateur a déjà 3 posts aujourd'hui
    IF nb_posts_max > 3 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Limite de 3 posts par jour atteinte. Réessayez demain.';
    END IF;
END//

DELIMITER ;


-- ========================================
-- Limiter les commentaires (anti-flooding)
-- ========================================

DELIMITER //

CREATE TRIGGER commentaires_flooding
    BEFORE INSERT ON commentaires
    FOR EACH ROW
BEGIN
    DECLARE nb_commentaires INT;
    
    -- Compter le nombre de commentaires des 5 dernières minutes
    SELECT COUNT(*) INTO nb_commentaires
    FROM commentaires 
    WHERE idUtilisateur = NEW.idUtilisateur 
    AND date >= DATE_SUB(NOW(), INTERVAL 5 MINUTE);
    
    -- Si plus de 2 commentaires en 5 minutes, bloquer
    IF nb_commentaires > 2 THEN
        SIGNAL SQLSTATE '45001' 
        SET MESSAGE_TEXT = 'Trop de commentaires postés rapidement. Attendez 5 minutes.';
    END IF;
END//

DELIMITER ;