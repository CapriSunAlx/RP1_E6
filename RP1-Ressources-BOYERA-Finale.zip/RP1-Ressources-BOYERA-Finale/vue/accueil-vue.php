<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum Accueil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Contenu principal de la page -->
    <div class="container mt-5 text-center">
        <h1>Bienvenue sur le Forum du BTS SIO</h1>
        <p>Rejoignez la discussion, publiez et partagez vos idées.</p>
    </div>

    <?php //print_r($_SESSION);?>

    <!-- Section des catégories -->
    <div class="container my-5">
        <div class="row">
            <!-- En Commun -->
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                <a href="categorie.php?categorie_id=1">
                    <img src="images/logo-btssio.png" class="card-img-top" alt="En Commun">
                </a>
                    <div class="card-body">
                        <h5 class="card-title">En Commun</h5>
                        <p class="card-text">Discussions et échanges sur des sujets communs à tous les étudiants BTS SIO.</p>
                        <a href="categorie.php?categorie_id=1" class="btn btn-primary">Accéder à la catégorie</a>
                
                    </div>
                </div>
            </div>

            <!-- Option SISR -->
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                <a href="categorie.php?categorie_id=2">
                <img src="images/sisr.png" class="card-img-top" alt="SISR">
                </a>
                    <div class="card-body">
                        <h5 class="card-title">Option SISR</h5>
                        <p class="card-text">Solutions d'Infrastructure, Systèmes et Réseaux</p>
                        <a href="categorie.php?categorie_id=2" class="btn btn-primary">Accéder à la catégorie</a>
                    </div>
                </div>
            </div>

            <!-- Option SLAM -->
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                <a href="categorie.php?categorie_id=3">
                <img src="images/slam.png" class="card-img-top" alt="SISR">
                </a>
                    <div class="card-body">
                        <h5 class="card-title">Option SLAM</h5>
                        <p class="card-text">Solutions Logicielles et Applications Métiers - Discussions sur le développement logiciel.</p>
                        <a href="categorie.php?categorie_id=3" class="btn btn-primary">Accéder à la catégorie</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
