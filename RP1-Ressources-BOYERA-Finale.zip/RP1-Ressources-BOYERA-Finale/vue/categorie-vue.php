<?php
require_once 'include/bandeau.php';
?>
<h1>Posts de la catégorie</h1>

<!-- Affichage des posts -->
<?php if (empty($posts)): ?>
    <p>Personne n'a encore posté dans cette catégorie pour le moment.</p>
<?php else: ?>
    <div class="list-group">
        <?php foreach ($posts as $post): ?>
            <div class="list-group-item">
                <h4><a href="index.php?page=post&id=<?= $post['id'] ?>" class="text-decoration-none"><?= $post['titre'] ?></a></h4>
                <p class="text-muted">Discussion créée par : <?= $post['prenom'] ?> <?= $post['nom'] ?></p>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Bouton pour ajouter un post -->
<i class="fa fa-plus-circle fa-3x" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#modal-ajouter-post" 
    style="position: fixed; bottom: 20px; right: 20px; z-index: 1050; color:blue;"></i> 

<!-- Modal pour ajouter un post -->
<div class="modal fade" id="modal-ajouter-post" tabindex="-1" aria-labelledby="Ajouter-Post" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="Ajouter-Post">Ajouter un post</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" action="controleur/PostController.php" class="container mt-4">
             <input type="hidden" name="idCategorie" value="<?= $_GET['categorie_id'] ?>">

          <div class="mb-3">
            <label for="titre" class="form-label">Titre :</label>
            <input type="text" name="titre" class="form-control" required>
          </div>

          <div class="mb-3">
            <label for="contenu" class="form-label">Contenu :</label>
            <textarea name="contenu" class="form-control" required></textarea>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
            <button type="submit" name="ajouter" class="btn btn-primary">Ajouter le post</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php
if (isset($_SESSION['error_post'])) {
    echo '<div class="alert alert-danger text-center">' . $_SESSION['error_post'] . '</div>';
    unset($_SESSION['error_post']);
}

?>


<br>

<a href="index.php">Retour à l'accueil</a>
