<?php

if (isset($_SESSION['id'])) {
    $userData = [
        'nom' => $_SESSION['nom'],
        'prenom' => $_SESSION['prenom'],
        'email' => $_SESSION['email'],
    ];
} else {
    $userData = null;

}
?>


<?php if ($userData): ?>
    <p>Nom : <?= $userData['nom'] ?></p>
    <p>Prénom : <?= $userData['prenom'] ?></p>
    <p>Email : <?= $userData['email'] ?></p>
<?php else: ?>

<?php endif; ?>
