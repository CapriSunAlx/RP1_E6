<?php
require_once 'include/bandeau.php';
?>
<!-- Formulaire de reset du mdp -->
<div class="container mt-5">
    <h2 class="text-center">Réinitialiser son mot de passe</h2>
    
  <form method="POST" action="index.php?page=connexion&action=reinit">
    <label>Email : <input type="email" name="email" required></label>
    <button type="submit">Réinitialiser le mot de passe</button>
</form>
        
    <!-- affichage message d'erreur -->
    <?php if (isset($message)): ?>
        <br>
        <div class="alert alert-danger text-center">
            <?= $message; ?>
        </div>
    <?php endif; ?>

</div>
