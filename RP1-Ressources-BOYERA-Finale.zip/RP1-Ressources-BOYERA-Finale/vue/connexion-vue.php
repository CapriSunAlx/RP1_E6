<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Forum</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>
<!-- Formulaire de connexion -->
<div class="container mt-5">
    <h2 class="text-center">Se connecter</h2>
    
   <form action="index.php?page=connexion" method="POST" class="w-70 mx-auto">
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="mot_de_passe" class="form-label">Mot de passe</label>
            <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Se connecter</button>
    </form>
        
    <!-- affichage message d'erreur -->
    <?php if (isset($message)): ?>
        <br>
        <div class="alert alert-danger text-center">
            <?= $message; ?>
        </div>
    <?php endif; ?>
    
    <!-- <p class="text-center mt-3">Pas encore inscrit ? <a href="inscription.php">Créez un compte</a></p> -->
    <p class="text-center mt-3"><a href="index.php?page=mdp-oublie">Mot de passe oublié ?</a></p>

</div>
