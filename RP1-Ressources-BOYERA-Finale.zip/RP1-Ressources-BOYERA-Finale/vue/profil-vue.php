<h2 class="mb-0 text-primary center" style="text-align: center;">Mon Profil</h2>
<div class="partbts2">
    <div class="container mt-5" style="max-width: 1200px; width: 100%; display: flex; flex-wrap: wrap; gap: 20px; margin: 0 auto; justify-content: center;">
        
        <div class="row">
            <div class="card mb-4">
                <div class="card-header bg-light" bis_skin_checked="1">
                    <h5 class="mb-0">Mes informations</h5>
                </div>
                <div class="card-body d-flex align-items-center">
                    <img src="<?= !empty($utilisateur['photo_profil']) ? htmlspecialchars($utilisateur['photo_profil']) : 'images/profil.png'; ?>" 
                         alt="Photo de profil" class="rounded-circle me-4" width="120" height="120" style="object-fit: cover;">
                    <div>
                        <p class="mb-1"><strong>Nom :</strong> <?= htmlspecialchars($utilisateur['nom']); ?></p>
                        <p class="mb-1"><strong>Prénom :</strong> <?= htmlspecialchars($utilisateur['prenom']); ?></p>
                        <p class="mb-1"><strong>Email :</strong> <?= htmlspecialchars($utilisateur['email']); ?></p>
                        <p class="mb-1"><strong>Date d'inscription :</strong> le <?= date('d/m/Y', strtotime($utilisateur['date_inscription'])); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Formulaire pour modifier la photo -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Modifier mes informations</h5>
            </div>
            <div class="card-body">
                <h5>Changer ma photo de profil</h5>
                <form action="index.php?page=profil&action=modifierPhoto" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="photo" class="form-label">Choisir une nouvelle photo :</label>
                        <input type="file" name="photo" id="photo" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp" required>
                        <div class="form-text">Formats acceptés : JPG, PNG, GIF, WebP. Taille max : 5MB</div>
                    </div>
                    <button type="submit" class="btn btn-primary">Mettre à jour</button>
                </form>

                <!-- Messages pour la photo de profil -->
                <?php if (!empty($_SESSION['messagepdp'])): ?>
                    <div class="alert alert-success mt-3"><?= htmlspecialchars($_SESSION['messagepdp']); ?></div>
                    <?php unset($_SESSION['messagepdp']); ?>
                <?php endif; ?>
                
                <br>
                
                <h5>Changer mon mot de passe</h5>
                <!-- Bouton modifier mot de passe -->
                <div class="text-start">
                    <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modal-modifier-mdp">
                        <i class="fa fa-lock me-2"></i>Modifier mon mot de passe
                    </button>
                </div>
            </div>
        </div>

        <!-- Messages mot de passe -->
        <?php if (!empty($_SESSION['messageMdp'])): ?>
            <div class="alert alert-success mt-3"><?= htmlspecialchars($_SESSION['messageMdp']); ?></div>
            <?php unset($_SESSION['messageMdp']); ?>
        <?php endif; ?>

        <?php if (!empty($_SESSION['erreurMdp'])): ?>
            <div class="alert alert-danger mt-3"><?= htmlspecialchars($_SESSION['erreurMdp']); ?></div>
            <?php unset($_SESSION['erreurMdp']); ?>
        <?php endif; ?>

    </div>
</div>

<!-- Modal modification mot de passe -->
<div class="modal fade" id="modal-modifier-mdp" tabindex="-1" aria-labelledby="Modifier-mdp" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="Modifier-mdp">Modifier son mot de passe</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="index.php?page=profil&action=changerMotDePasse">
                    <div class="mb-3">
                        <label for="ancien_mdp" class="form-label">Ancien mot de passe :</label>
                        <input type="password" name="ancien_mdp" id="ancien_mdp" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="nouveau_mdp" class="form-label">Nouveau mot de passe :</label>
                        <input type="password" name="nouveau_mdp" id="nouveau_mdp" class="form-control" required minlength="8">
                        <div class="form-text">Au moins 8 caractères avec une majuscule, une minuscule et un chiffre</div>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_mdp" class="form-label">Confirmer le nouveau mot de passe :</label>
                        <input type="password" name="confirm_mdp" id="confirm_mdp" class="form-control" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Changer le mot de passe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>