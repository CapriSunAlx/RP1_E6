<?php
require_once 'include/outils_bd.php';
require_once 'include/bandeau.php';
require_once 'modele/Commentaire.php';
require_once 'vue/post-vue.php';
if (!isset($_GET['id'])) {
    header('Location: commun.php');
    exit();
}

// Récupérer les infos du post
$idPost = $_GET['id'];
$requete = $pdo->prepare("SELECT posts.*, utilisateurs.nom, utilisateurs.prenom, utilisateurs.photo_profil 
                          FROM posts 
                          INNER JOIN utilisateurs ON posts.utilisateur_id = utilisateurs.id 
                          WHERE posts.id = ?");
$requete->execute([$idPost]);
$post = $requete->fetch();

if (!$post) {
    echo "Post introuvable.";
    exit();
}

// photo profil
$image_profil = !empty($post['photo_profil']) ? $post['photo_profil'] : 'images/profil.png';

// Table de correspondance idCategorie => nom
$categories = [
    1 => 'En commun',
    2 => 'SISR',
    3 => 'SLAM'
];

// Catégorie du post
if (isset($categories[$post['idCategorie']])) {
    $nomCategorie = $categories[$post['idCategorie']];
} else {
    $nomCategorie = 'Catégorie inexistante';
}
?>

<!-- Fil d'Ariane -->
<div class="container mt-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?page=accueil">Forum</a></li>
      <li class="breadcrumb-item">
        <a href="categorie.php?categorie_id=<?= $post['idCategorie'] ?>">
          <?= $nomCategorie ?>
        </a>
      </li>
      <li class="breadcrumb-item active" aria-current="page"><?= $post['titre'] ?></li>
    </ol>
  </nav>
</div>


<!-- Affichage du post -->
<div class="container mt-4">
    <div class="card mb-3">
        <div class="row no-gutters">
            <div class="col-md-3">
                <img src="<?= $image_profil ?>" class="card-img" alt="Photo de profil">
                <h5 class="text-center"><?= $post['prenom'] ?> <?= $post['nom'] ?></h5>
            </div>
            <div class="col-md-9 d-flex flex-column">
                <div class="card-body" style="border-left: 1px solid #ccc;">
                    <h4><?= $post['titre'] ?></h4>
                    <p><?= nl2br($post['contenu']) ?></p>
                </div>
                <div class="card-footer text-end text-muted">
                    Posté le <?= date("d/m/Y H:i", strtotime($post['date_post'])) ?>
                </div>
            </div>
        </div>
    </div>

<!-- Affichage des commentaires -->
 <?php 
// Récupérer les commentaires associés au post
$commentaires = Commentaire::getCommentairesParPost($idPost);
?>

<?php
if (isset($_SESSION['error_comment'])) {
    echo '<div class="alert alert-danger text-center">' . $_SESSION['error_comment'] . '</div>';
    unset($_SESSION['error_comment']);
}
?>

<h5>Commentaires (<?= count($commentaires) ?>)</h5>

<?php if (empty($commentaires)): ?>
    <p>Aucun commentaire pour le moment.</p>
<?php else: ?>
    <?php foreach ($commentaires as $com): ?>
    <div class="card mb-2 position-relative">
        <div class="row no-gutters">
            <div class="col-md-3">
              <img src="<?= !empty($com->photo_profil) ? $com->photo_profil : 'images/profil.png' ?>" class="card-img" alt="Photo">

                <h6 class="text-center"><?= $com->prenom ?> <?= $com->nom ?></h6>
            </div>

            <div class="col-md-9 d-flex flex-column position-relative">
                <!-- Supprimer un commentaire -->
                <?php if (isset($_SESSION['id']) && $_SESSION['id'] == $com->idUtilisateur): ?>
                    <a href="controleur/CommentaireController.php?supprimer=1&id=<?= $com->id ?>&post=<?= $idPost ?>"
                       onclick="return confirm('Voulez vous supprimer ce commentaire ?')"
                       style="display:flex; justify-content: flex-end;">
                    <i class="fa fa-trash"></i>
                    </a>
                <?php endif; ?>

                <div class="card-body" style="border-left: 1px solid #ccc;">
                    <p><?= $com->contenu ?></p>
                </div>
                <div class="card-footer text-end text-muted">
                    Commenté le <?= date("d/m/Y H:i", strtotime($com->dateCommentaire)) ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Formulaire pour ajouter un commentaire -->
<?php if (isset($_SESSION['id'])): ?>
    <div class="card mb-4">
        <div class="card-body">
            <form method="post" action="controleur/CommentaireController.php">
                <input type="hidden" name="idPost" value="<?= $idPost ?>">
                <label for="contenu">Votre commentaire :</label>
                <textarea name="contenu" id="contenu" class="form-control" rows="3" required></textarea>
                <button type="submit" class="btn btn-primary mt-2">Poster</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <p class="text-muted">Vous devez être connecté pour laisser un commentaire.</p>
<?php endif; ?>   
</div>

