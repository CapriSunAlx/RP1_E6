<?php
require_once 'controleur/InscriptionController.php';
require_once 'include/bandeau.php';

$controleur = new InscriptionController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $controleur->traiterInscription($_POST);
} else {
    $controleur->afficherFormulaire();
}

?>
